package com.dgsw.studyjpa.repository;

import com.dgsw.studyjpa.entity.FreeBoard;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FreeBoardRepository extends JpaRepository<FreeBoard,Long> {
}
